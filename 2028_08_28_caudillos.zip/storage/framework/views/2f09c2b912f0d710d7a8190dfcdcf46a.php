<?php if(session()->has('message')): ?>
    <div class="text-danger" role="alert">
        <div class="flex">
            <div>
                <p class="text-sm"><?php echo e(session('message')); ?></p>
            </div>
        </div>
    </div>
<?php endif; ?>
<?php /**PATH C:\laragon\www\caudillos\resources\views/common/crud_message.blade.php ENDPATH**/ ?>