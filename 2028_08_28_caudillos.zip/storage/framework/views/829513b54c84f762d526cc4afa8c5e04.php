<div>
   <div class="container mt-2">

    <div class="card">
        <p class="text-center">JORNADAS</p>
            <div class="card-body">

                <?php $__currentLoopData = $rounds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $round): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="btn-group" role="group" aria-label="Basic radio toggle button group">
                        <div class="ml-3">
                            <button wire:click="select_round(<?php echo e($round->id); ?>)"
                                class="btn  waves-effect waves-light
                                    <?php echo e($current_round->id == $round->id ? 'btn-success'  : ''); ?>

                                    <?php echo e($selected_round->id == $round->id ? 'btn-warning' : ''); ?>"
                            title="<?php echo e($round->id); ?>">
                           <?php echo e($round->id); ?>


                        </button>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
    </div>

   </div>
</div>
<?php /**PATH C:\laragon\www\caudillos\resources\views/livewire/rounds/select-round.blade.php ENDPATH**/ ?>