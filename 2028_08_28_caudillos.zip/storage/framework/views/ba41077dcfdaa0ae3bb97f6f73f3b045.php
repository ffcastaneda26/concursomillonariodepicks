<div class="table-responsive">
    <table class="table table-striped table-hover">
        <thead class="thead">
            <tr>
                <th>Nombre Website</th>
                <th>Url</th>
                <th>Correo</th>
                <th>¿Pedir Resultados?</th>
                <th>Minutos Pronóstico</th>
                <th>¿Empates?</th>
                <th>¿Crear Pronósticos?</th>
                <th>¿Pago Para Continuar?</th>
                <th>¿Datos P/Continuar?</th>
                <th>¿Rol en Registro?</th>
                <th>¿Crear en Stripe?</th>
                <th>¿Equipo para desempate?</th>
                <th></th>
            </tr>
        </thead>
        <tbody>
                <tr>
                    <td><?php echo e($configuration->website_name); ?></td>
                    <td><?php echo e($configuration->website_url); ?></td>
                    <td><?php echo e($configuration->email); ?></td>
                    <td align="center">
                        <img src="<?php echo e($configuration->score_picks ? asset('images/afirmativo.png') : asset('images/negativo.png')); ?>"
                            alt="<?php echo e($configuration->score_picks ? __('Yes') : 'No'); ?>"
                            height="24px"
                            width="24px">
                    </td>
                    <td align="center"><?php echo e($configuration->minuts_before_picks); ?></td>

                    <td align="center">
                        <img src="<?php echo e($configuration->allow_tie ? asset('images/afirmativo.png') : asset('images/negativo.png')); ?>"
                        alt="<?php echo e($configuration->allow_tie ? __('Yes') : 'No'); ?>"
                        height="24px"
                        width="24px">
                    </td>



                    <td align="center">
                        <img src="<?php echo e($configuration->create_mssing_picks ? asset('images/afirmativo.png') : asset('images/negativo.png')); ?>"
                        alt="<?php echo e($configuration->create_mssing_picks ? __('Yes') : 'No'); ?>"
                        height="24px"
                        width="24px">
                    </td>

                    <td align="center">
                        <img src="<?php echo e($configuration->require_payment_to_continue ? asset('images/afirmativo.png') : asset('images/negativo.png')); ?>"
                        alt="<?php echo e($configuration->require_payment_to_continue ? __('Yes') : 'No'); ?>"
                        height="24px"
                        width="24px">
                    </td>

                    <td align="center">
                        <img src="<?php echo e($configuration->require_data_user_to_continue ? asset('images/afirmativo.png') : asset('images/negativo.png')); ?>"
                        alt="<?php echo e($configuration->require_data_user_to_continue ? __('Yes') : 'No'); ?>"
                        height="24px"
                        width="24px">
                    </td>

                    <td align="center">
                        <img src="<?php echo e($configuration->assig_role_to_user ? asset('images/afirmativo.png') : asset('images/negativo.png')); ?>"
                        alt="<?php echo e($configuration->assig_role_to_user ? __('Yes') : 'No'); ?>"
                        height="24px"
                        width="24px">
                    </td>

                    <td align="center">
                        <img src="<?php echo e($configuration->add_user_to_stripe ? asset('images/afirmativo.png') : asset('images/negativo.png')); ?>"
                        alt="<?php echo e($configuration->add_user_to_stripe ? __('Yes') : 'No'); ?>"
                        height="24px"
                        width="24px">
                    </td>

                    <td align="center">
                        <img src="<?php echo e($configuration->use_team_to_tie_breaker ? asset('images/afirmativo.png') : asset('images/negativo.png')); ?>"
                        alt="<?php echo e($configuration->use_team_to_tie_breaker ? __('Yes') : 'No'); ?>"
                        height="24px"
                        width="24px">
                    </td>

                    <td>
                        <button
                            wire:click="edit(<?php echo e($configuration->id); ?>)"
                            class="btn btn-success waves-effect waves-light"
                            title="<?php echo e(__("Edit")); ?>">
                            <i class="mdi mdi-eye-circle"></i>
                        </button>
                    </td>

                </tr>

        </tbody>
    </table>
</div>
<?php /**PATH C:\laragon\www\caudillos\resources\views/livewire/configurations/table.blade.php ENDPATH**/ ?>