    <div class="container">
        
        <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.validation-errors','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('validation-errors'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
        <div class="row align-items-start">



            <div class="col flex flex-col mt-2">
                
                <div class="input-group mb-3">
                    <span class="input-group-text" id="basic-addon1">Nombre Sitio</span>
                    <input type="text"
                            wire:model="main_record.website_name"
                            required
                            placeholder="Nombre"
                            class="form-control mb-2"
                            size="30"
                            maxlength="150">
                </div>

                
                <div class="input-group mb-3">
                    <span class="input-group-text" id="basic-addon1">Url</span>
                    <input type="text"
                            wire:model="main_record.website_url"
                            required
                            placeholder="Url"
                            class="form-control mb-2"
                            size="30"
                            maxlength="150">
                </div>


                <div class="input-group mb-3">
                    <span class="input-group-text" id="basic-addon1">Correo</span>
                    <input type="text"
                            wire:model="main_record.email"
                            required
                            placeholder="Url"
                            class="form-control mb-2 <?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>"
                            size="30"
                            maxlength="100">
                </div>

                
                <div class="input-group mb-3">
                    <span class="input-group-text" id="basic-addon1">Minutos Para Pronosticar</span>
                    <input type="number"
                            wire:model="main_record.minuts_before_picks"
                            required
                            class="mb-2 <?php echo e($errors->has('minuts_before_picks') ? ' is-invalid' : ''); ?>"
                            size="3"
                            maxlength="4">
                </div>


                <div class="flex flex-row justify-between">
                    
                    <div class="input-group mb-3">
                        <span class="input-group-text" id="basic-addon1">¿Pedir Resultados?</span>
                            <div class="btn-group" role="group" aria-label="Basic radio toggle button group">
                                <input type="radio" wire:model="score_picks" class="btn-check" name="score_picks" id="score_picks_yes" value="1">
                                <label class="mr-2 btn btn-outline-success" for="score_picks_yes">
                                    <img src="<?php echo e(asset('images/afirmativo.png')); ?>" alt="SI" width="24px" height="24px">
                                </label>

                                <input type="radio" wire:model="score_picks" class="btn-check ml-4" name="score_picks" id="score_picks_no" value="0">
                                <label class="ml-5 btn btn-outline-danger" for="score_picks_no">
                                    <img src="<?php echo e(asset('images/negativo.png')); ?>" alt="NO" width="24px" height="24px">
                                </label>
                            </div>
                    </div>

                    
                    <div class="input-group mb-3">
                        <span class="input-group-text" id="basic-addon1">¿Permite Empates??</span>
                            <div class="btn-group" role="group" aria-label="Basic radio toggle button group">
                                <input type="radio" wire:model="allow_tie" class="btn-check" name="allow_tie" id="allow_tie_yes" value="1">
                                <label class="mr-2 btn btn-outline-success" for="allow_tie_yes">
                                    <img src="<?php echo e(asset('images/afirmativo.png')); ?>" alt="SI" width="24px" height="24px">
                                </label>

                                <input type="radio" wire:model="allow_tie" class="btn-check ml-4" name="allow_tie" id="allow_tie_no" value="0">
                                <label class="ml-5 btn btn-outline-danger" for="allow_tie_no">
                                    <img src="<?php echo e(asset('images/negativo.png')); ?>" alt="NO" width="24px" height="24px">
                                </label>
                            </div>
                    </div>

                    
                    <div class="input-group mb-3">
                        <span class="input-group-text" id="basic-addon1">¿Crear Pronósticos Faltantes?</span>
                        <div class="btn-group" role="group" aria-label="Basic radio toggle button group">
                            <input type="radio" wire:model="create_mssing_picks" class="btn-check" name="create_mssing_picks" id="create_mssing_picks_yes" value="1">
                            <label class="mr-2 btn btn-outline-success" for="create_mssing_picks_yes">
                                <img src="<?php echo e(asset('images/afirmativo.png')); ?>" alt="SI" width="24px" height="24px">
                            </label>

                            <input type="radio" wire:model="create_mssing_picks" class="btn-check ml-4" name="create_mssing_picks" id="create_mssing_picks_no" value="0">
                            <label class="ml-5 btn btn-outline-danger" for="create_mssing_picks_no">
                                <img src="<?php echo e(asset('images/negativo.png')); ?>" alt="NO" width="24px" height="24px">
                            </label>
                        </div>
                    </div>
                </div>

                <div class="flex flex-col">

                    
                    <div class="input-group mb-3">
                        <span class="input-group-text" id="basic-addon1">¿Requiere Pago Para Continuar?</span>
                            <div class="btn-group" role="group" aria-label="Basic radio toggle button group">
                                <input type="radio" wire:model="require_payment_to_continue" class="btn-check" name="require_payment_to_continue" id="require_payment_to_continue_yes" value="1">
                                <label class="mr-2 btn btn-outline-success" for="require_payment_to_continue_yes">
                                    <img src="<?php echo e(asset('images/afirmativo.png')); ?>" alt="SI" width="24px" height="24px">
                                </label>

                                <input type="radio" wire:model="require_payment_to_continue" class="btn-check ml-4" name="require_payment_to_continue" id="require_payment_to_continue_no" value="0">
                                <label class="ml-5 btn btn-outline-danger" for="require_payment_to_continue_no">
                                    <img src="<?php echo e(asset('images/negativo.png')); ?>" alt="NO" width="24px" height="24px">
                                </label>
                            </div>
                    </div>

                    
                    <div class="input-group mb-3">
                        <span class="input-group-text" id="basic-addon1">¿Requiere Datos Complementarios Para Continuar?</span>
                            <div class="btn-group" role="group" aria-label="Basic radio toggle button group">
                                <input type="radio" wire:model="require_data_user_to_continue" class="btn-check" name="require_data_user_to_continue" id="require_data_user_to_continue_yes" value="1">
                                <label class="mr-2 btn btn-outline-success" for="require_data_user_to_continue_yes">
                                    <img src="<?php echo e(asset('images/afirmativo.png')); ?>" alt="SI" width="24px" height="24px">
                                </label>

                                <input type="radio" wire:model="require_data_user_to_continue" class="btn-check ml-4" name="require_data_user_to_continue" id="require_data_user_to_continue_no" value="0">
                                <label class="ml-5 btn btn-outline-danger" for="require_data_user_to_continue_no">
                                    <img src="<?php echo e(asset('images/negativo.png')); ?>" alt="NO" width="24px" height="24px">
                                </label>
                            </div>
                    </div>
                </div>

                
                <div class="input-group mb-3">
                    <span class="input-group-text" id="basic-addon1">¿Asignar Rol Al Registrarse?</span>
                        <div class="btn-group" role="group" aria-label="Basic radio toggle button group">
                            <input type="radio" wire:model="assig_role_to_user" class="btn-check" name="assig_role_to_user" id="assig_role_to_user_yes" value="1">
                            <label class="mr-2 btn btn-outline-success" for="assig_role_to_user_yes">
                                <img src="<?php echo e(asset('images/afirmativo.png')); ?>" alt="SI" width="24px" height="24px">
                            </label>

                            <input type="radio" wire:model="assig_role_to_user" class="btn-check ml-4" name="assig_role_to_user" id="assig_role_to_user_no" value="0">
                            <label class="ml-5 btn btn-outline-danger" for="assig_role_to_user_no">
                                <img src="<?php echo e(asset('images/negativo.png')); ?>" alt="NO" width="24px" height="24px">
                            </label>
                        </div>
                </div>


                
                <div class="input-group mb-3">
                    <span class="input-group-text" id="basic-addon1">¿Crear Usuario en Stripe?</span>
                        <div class="btn-group" role="group" aria-label="Basic radio toggle button group">
                            <input type="radio" wire:model="add_user_to_stripe" class="btn-check" name="add_user_to_stripe" id="add_user_to_stripe_yes" value="1">
                            <label class="mr-2 btn btn-outline-success" for="add_user_to_stripe_yes">
                                <img src="<?php echo e(asset('images/afirmativo.png')); ?>" alt="SI" width="24px" height="24px">
                            </label>

                            <input type="radio" wire:model="add_user_to_stripe" class="btn-check ml-4" name="add_user_to_stripe" id="add_user_to_stripe_no" value="0">
                            <label class="ml-5 btn btn-outline-danger" for="add_user_to_stripe_no">
                                <img src="<?php echo e(asset('images/negativo.png')); ?>" alt="NO" width="24px" height="24px">
                            </label>
                        </div>
                </div>

                
                <div class="input-group mb-3">
                    <span class="input-group-text" id="basic-addon1">¿Usar Equipo para desempate?</span>
                        <div class="btn-group" role="group" aria-label="Basic radio toggle button group">
                            <input type="radio" wire:model="use_team_to_tie_breaker" class="btn-check" name="use_team_to_tie_breaker" id="use_team_to_tie_breaker_yes" value="1">
                            <label class="mr-2 btn btn-outline-success" for="use_team_to_tie_breaker_yes">
                                <img src="<?php echo e(asset('images/afirmativo.png')); ?>" alt="SI" width="24px" height="24px">
                            </label>

                            <input type="radio" wire:model="use_team_to_tie_breaker" class="btn-check ml-4" name="use_team_to_tie_breaker" id="use_team_to_tie_breaker_no" value="0">
                            <label class="ml-5 btn btn-outline-danger" for="use_team_to_tie_breaker_no">
                                <img src="<?php echo e(asset('images/negativo.png')); ?>" alt="NO" width="24px" height="24px">
                            </label>
                        </div>
                </div>

                

                <?php if($use_team_to_tie_breaker): ?>
                    <div class="input-group mb-3">
                        <span class="input-group-text" id="basic-addon1">Equipo para desempate</span>
                        <select wire:model="team_id">
                            <option value="">Seleccione</option>
                            <?php $__currentLoopData = $teams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $team): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($team->id); ?>"  <?php echo e($team->id == $team_id ? 'selected' : ''); ?>>
                                    <?php echo e($team->name); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>

                    </div>
                <?php endif; ?>


            </div>


        </div>


    </div>
<?php /**PATH C:\laragon\www\caudillos\resources\views/livewire/configurations/form.blade.php ENDPATH**/ ?>