
<img class="rounded-xs" src="<?php echo e(asset('images/logo.png')); ?>" alt="Logo" width="64px" height="64px">
<?php /**PATH C:\laragon\www\caudillos\resources\views/components/application-mark.blade.php ENDPATH**/ ?>