
<div class="d-flex justify-content-end">
    <?php if($allow_edit): ?>
        <span class="mx-2">
            <button wire:click="closeModal()"
                class="btn btn-danger">
                <?php echo e(__("Cancel")); ?>

            </button>
        </span>
        <span class="mx-2">
            <button wire:click.prevent="store()"
                class="btn btn-success">
                <?php echo e(__("Save")); ?>

            </button>
        </span>
    <?php else: ?>
        <span class="mx-2">
            <button wire:click="closeModal()"
                class="btn btn-success">
                Regresar
            </button>
        </span>
    <?php endif; ?>

</div>
<?php /**PATH C:\laragon\www\caudillos\resources\views/common/crud_save_cancel.blade.php ENDPATH**/ ?>