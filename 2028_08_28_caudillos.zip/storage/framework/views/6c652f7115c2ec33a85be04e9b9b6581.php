    
    <td><?php echo e($game->visit_points); ?></td>
    <td><img src="<?php echo e(Storage::url($game->visit_team->logo)); ?>" class="avatar-sm" alt="" width="100px" height="100px"></td>
    <td><?php echo e($game->visit_team->alias); ?></td>
<?php /**PATH C:\laragon\www\caudillos\resources\views/livewire/picks/pick_visit.blade.php ENDPATH**/ ?>