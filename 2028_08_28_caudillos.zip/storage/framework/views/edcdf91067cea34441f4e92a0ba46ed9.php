   
   <td><?php echo e($game->local_team->alias); ?></td>
   <td><img src="<?php echo e(Storage::url($game->local_team->logo)); ?>" class="avatar-sm" alt="" width="100px" height="100px"></td>
   <td><?php echo e($game->local_points); ?></td>
<?php /**PATH C:\laragon\www\caudillos\resources\views/livewire/picks/picks_local.blade.php ENDPATH**/ ?>