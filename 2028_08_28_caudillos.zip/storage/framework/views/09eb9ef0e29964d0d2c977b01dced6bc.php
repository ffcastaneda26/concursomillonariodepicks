
<img class="rounded-xs" src="<?php echo e(asset('images/logo.png')); ?>" alt="Logo">
<?php /**PATH C:\laragon\www\caudillos\resources\views/components/application-logo.blade.php ENDPATH**/ ?>