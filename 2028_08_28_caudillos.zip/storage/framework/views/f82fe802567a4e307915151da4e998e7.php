<div class="mt-5">
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('select-round')->html();
} elseif ($_instance->childHasBeenRendered('l3919674848-0')) {
    $componentId = $_instance->getRenderedChildComponentId('l3919674848-0');
    $componentTag = $_instance->getRenderedChildComponentTagName('l3919674848-0');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l3919674848-0');
} else {
    $response = \Livewire\Livewire::mount('select-round');
    $html = $response->html();
    $_instance->logRenderedChild('l3919674848-0', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    <div class="container-fluid mt-2">
        <?php if(isset($message)): ?>
            <div class="text-red-600 text-danger text-center text-3xl">
                <h1><?php echo e($message); ?></h1>
            </div>
        <?php endif; ?>


        <?php if(isset($round_games) && !empty($round_games)): ?>
            <div class="row">
                <div class="col-sm-12">
                    <div class="card">
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table text-xs">
                                    <thead class="thead">
                                        <tr class="bg-dark text-white text-center text-sm">
                                            
                                            <th>Participante</th>
                                            <?php $__currentLoopData = $round_games; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $game): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <td><?php echo e($game->visit_team->short); ?> - <?php echo e($game->local_team->short); ?></td>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tr>
                                    </thead>

                                    <tbody>
                                        <?php
                                            $participante_anterior = null;
                                            $previous_pick = null;
                                        ?>

                                        <?php $__currentLoopData = $round_picks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pick): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                            <?php if($pick->user_id != $participante_anterior): ?>
                                                 <?php if(!is_null($previous_pick)): ?>
                                                    <?php if($previous_pick->game->allow_pick()): ?>
                                                        <td align="center">
                                                            <img src="<?php echo e(asset('images/reloj.jpg')); ?>" alt="" width="32px" height="32px">
                                                        </td>
                                                    <?php else: ?>
                                                    <td align="center" class="<?php echo e($previous_pick->hit ? 'bg-success' : 'bg-danger'); ?>">
                                                            <img src="<?php echo e($previous_pick->winner == 1 ? Storage::url($previous_pick->game->local_team->logo) : Storage::url($previous_pick->game->visit_team->logo)); ?>"
                                                                alt="<?php echo e($previous_pick->winner == 1 ? $previous_pick->game->local_team->short : $previous_pick->game->visit_team->short); ?>"
                                                                width="45px"
                                                                height="45px">
                                                            <span>
                                                                <img src="<?php echo e($previous_pick->hit  ?   asset('images/afirmativo.png') : asset('images/negativo.png')); ?>"
                                                                            alt="<?php echo e($pick->hit  ?  __('Yes') : 'No'); ?>"
                                                                            height="12px"
                                                                            width="12px">
                                                            </span>
                                                        </td>
                                                    <?php endif; ?>
                                                <?php endif; ?>
                                                </tr>
                                                <td><?php echo e($pick->user->name); ?></td>
                                            <?php endif; ?>

                                            <?php if($pick->user_id == $participante_anterior): ?>
                                                    <?php if($pick->game->allow_pick()): ?>
                                                        <td align="center">
                                                            <img src="<?php echo e(asset('images/reloj.jpg')); ?>" alt="" width="32px" height="32px">
                                                        </td>
                                                    <?php else: ?>
                                                    <td align="center" class="<?php echo e($pick->hit ? 'bg-success' : 'bg-danger'); ?>">
                                                            <img src="<?php echo e($pick->winner == 1 ? Storage::url($pick->game->local_team->logo) : Storage::url($pick->game->visit_team->logo)); ?>"
                                                                alt="<?php echo e($pick->winner == 1 ? $pick->game->local_team->short : $pick->game->visit_team->short); ?>"
                                                                width="45px"
                                                                height="45px">
                                                            <span>
                                                                <img src="<?php echo e($pick->hit  ?   asset('images/afirmativo.png') : asset('images/negativo.png')); ?>"
                                                                            alt="<?php echo e($pick->hit  ?  __('Yes') : 'No'); ?>"
                                                                            height="12px"
                                                                            width="12px">
                                                            </span>
                                                        </td>
                                                    <?php endif; ?>
                                            <?php endif; ?>

                                            <?php
                                                $participante_anterior = $pick->user_id;
                                                $previous_pick = $pick;
                                            ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php if(!is_null($previous_pick)): ?>
                                            <?php if($previous_pick->game->allow_pick()): ?>
                                                <td align="center">
                                                    <img src="<?php echo e(asset('images/reloj.jpg')); ?>" alt="" width="32px" height="32px">
                                                </td>
                                            <?php else: ?>
                                            <td align="center" class="<?php echo e($previous_pick->hit ? 'bg-success' : 'bg-danger'); ?>">
                                                    <img src="<?php echo e($previous_pick->winner == 1 ? Storage::url($previous_pick->game->local_team->logo) : Storage::url($previous_pick->game->visit_team->logo)); ?>"
                                                        alt="<?php echo e($previous_pick->winner == 1 ? $previous_pick->game->local_team->short : $previous_pick->game->visit_team->short); ?>"
                                                        width="45px"
                                                        height="45px">
                                                    <span>
                                                        <img src="<?php echo e($previous_pick->hit  ?   asset('images/afirmativo.png') : asset('images/negativo.png')); ?>"
                                                                    alt="<?php echo e($pick->hit  ?  __('Yes') : 'No'); ?>"
                                                                    height="12px"
                                                                    width="12px">
                                                    </span>
                                                </td>
                                            <?php endif; ?>
                                        <?php endif; ?>

                                    </tbody>
                                </table>


                            </div>
                        </div>
                    </div>
                </div>
            </div>
        <?php endif; ?>
    </div>
</div>
<?php /**PATH C:\laragon\www\caudillos\resources\views/livewire/results/index.blade.php ENDPATH**/ ?>