<div class="py-12">
    <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
        <div class="bg-white dark:bg-gray-800 overflow-hidden shadow-xl sm:rounded-lg">

            <div class="container-fluid mt-2">
                        <?php echo $__env->make('common.crud_header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                        <?php echo $__env->make('common.crud_message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                        <div class="d-flex flex-row align-items-start col-md-12 gap-2 mb-2">
                            <div class="d-flex flex-row align-items-start col-md-8 gap-2 mb-2">
                                
                                <?php if($allow_create): ?>
                                    <?php echo $__env->make('common.crud_create_button', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                <?php endif; ?>
                            </div>
                        </div>
                        <?php if(!$allow_create): ?>
                            <?php if(isset($configuration)): ?>
                                <?php echo $__env->make('livewire.configurations.table', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <?php endif; ?>
                        <?php endif; ?>

                        
                        <?php if($isOpen && isset($view_form)): ?>
                            <?php echo $__env->make('common.crud_modal_form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <?php endif; ?>
            </div>
        </div>
    </div>

</div>
<?php /**PATH C:\laragon\www\caudillos\resources\views/livewire/configurations/index.blade.php ENDPATH**/ ?>