    
    <td>

        <?php if($pick_user && $game->has_result()): ?>

            <?php if($acerto): ?>
                <img src="<?php echo e(asset('images/afirmativo.png')); ?>" width="25" height="25">
             <?php else: ?>
                <img src="<?php echo e(asset('images/negativo.png')); ?>"   width="25" height="25">
            <?php endif; ?>
        <?php else: ?>
            <img src="<?php echo e(asset('images/balon.png')); ?>" alt="X" width="25" height="25">
        <?php endif; ?>
    </td>

<?php /**PATH C:\laragon\www\caudillos\resources\views/livewire/picks/pick_icono_acerto.blade.php ENDPATH**/ ?>