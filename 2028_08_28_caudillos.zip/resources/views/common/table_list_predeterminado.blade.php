<td align="center">
    <img src="{{ $record->predeterminado ? asset('images/afirmativo.png') : asset('images/negativo.png')}}"
    alt="{{ $record->predeterminado ? 'Si' : 'No' }}"
    height="17px"
    width="17px">
</td>

