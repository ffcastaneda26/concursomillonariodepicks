<a href="/">
    {{-- Clase: avatar-xx md=mediano sm=pequeño  xs=Extra pequeño lg=Largo xl=Extra largo --}}
    <img class="rounded-xs" src="{{asset('images/caudillos.png')}}" alt="Logo" height="150px" width="150px">
</a>
