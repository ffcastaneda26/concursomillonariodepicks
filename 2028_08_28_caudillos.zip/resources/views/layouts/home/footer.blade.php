<footer class="footer">
    <div class="container-fluid">
        <div class="row">
            <div class="d-flex justify-content-between">
                  <div class="text-sm-end d-none d-sm-block">
                    <script>document.write(new Date().getFullYear())</script> © Excellsus Group.
                </div>
            </div>
        </div>
    </div>
</footer>
