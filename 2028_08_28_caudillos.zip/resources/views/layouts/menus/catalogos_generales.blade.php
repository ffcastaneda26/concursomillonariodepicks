<li>
    <a href="javascript: void(0);" class="has-arrow waves-effect">
        <i class="mdi mdi-file-cabinet"></i>
        <span>Generales</span>
    </a>


    <ul class="sub-menu mm-collapse" aria-expanded="false">
        {{--Equipos --}}
        <li>
            <a href="{{route('teams')}}" class="waves-effect">
                <i class="mdi mdi-google-maps"></i>
                <span>Equipos</span>
            </a>
        </li>




    </ul>

</li>
