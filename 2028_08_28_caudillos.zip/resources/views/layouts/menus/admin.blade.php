<div id="sidebar-menu">

    <ul class="metismenu list-unstyled" id="side-menu">


        {{-- Catálogos --}}
        @include('layouts.menus.catalogos')


    </ul>
</div>
