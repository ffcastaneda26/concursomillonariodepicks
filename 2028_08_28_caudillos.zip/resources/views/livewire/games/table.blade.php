<thead class="thead">
    <tr class="bg-dark text-white text-center ">
        <th>Fecha</th>
        <th colspan="2">Visita</th>
        <th>Puntos Visita </th>
        <th>Puntos Local </th>
        <th colspan="2">Local</th>
        @role('Admin')
            <th>Poner Resultado </th>
        @endrole
    </tr>
</thead>
