<thead class="thead">
    <tr class="bg-dark text-white text-center">
        <th>Pos</th>
        <th>Participante  </th>
        <th>Aciertos</th>
        <th>¿Paritidos Desempate?</th>
        <th>Error Acumulado</th>
    </tr>
</thead>

