<div>
    @livewire('select-round')
    <div class="container-fluid mt-2">
        <div class="grid h-screen v-screen place-items-center">
            <div class="row">
                <div class="col-sm-12">
                    <div class="card">
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table">
                                    <tbody>
                                        <tr>
                                            <td align="center">
                                                <img class="rounded-xs" src="{{asset('images/en_construccion.jpg')}}" alt="EN CONSTRUCCION">
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
