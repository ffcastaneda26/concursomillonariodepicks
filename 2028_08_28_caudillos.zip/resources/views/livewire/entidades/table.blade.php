<thead>
    <tr class="bg-dark text-white text-center">
        <th>Entidad</th>
        <th>Abreviado</th>
        <th>Predeterminado</th>
        <th colspan="2" class="text-center">Acciones</th>
    </tr>
</thead>


