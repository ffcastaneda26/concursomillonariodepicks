   
   <td class="font-extrabold <?php echo e($acerto && $pick_user->winner == 1 ? 'text-2xl ' : 'text-xl'); ?>">
        <?php echo e($game->local_points); ?>

    </td>
   <td><?php echo e($game->local_team->alias); ?></td>
   <td><img src="<?php echo e(Storage::url($game->local_team->logo)); ?>" class="avatar-sm" alt="" width="100px" height="100px"></td>
<?php /**PATH C:\laragon\www\nacionnfl\resources\views/livewire/picks/picks_local.blade.php ENDPATH**/ ?>