<script src="https://cdn.jsdelivr.net/gh/alpinejs/alpine@v2.x.x/dist/alpine.min.js" defer></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script src="<?php echo e(asset('admiria/assets/js/jquery.min.js')); ?>"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.min.js"></script>
<script src="<?php echo e(asset('admiria/assets/js/metisMenu.min.js')); ?>></script>
<script src="<?php echo e(asset('admiria/assets/js/simplebar.min.js')); ?>></script>
<script src="<?php echo e(asset('admiria/assets/js/waves.min.js')); ?>></script>
<script src="<?php echo e(asset('admiria/assets/js/app.js')); ?>></script>
<script src="<?php echo e(asset('admiria/assets/js/my_functions.js')); ?>></script>
<?php /**PATH C:\laragon\www\nacionnfl\resources\views/layouts/home/javascript_files.blade.php ENDPATH**/ ?>