
<img class="rounded-xs" src="<?php echo e(asset('images/logo.jfif')); ?>" width="64px" height="64px">
<?php /**PATH C:\laragon\www\nacionnfl\resources\views/components/application-mark.blade.php ENDPATH**/ ?>