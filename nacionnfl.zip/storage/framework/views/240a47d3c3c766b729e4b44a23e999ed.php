<div>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('select-round')->html();
} elseif ($_instance->childHasBeenRendered('l1100580637-0')) {
    $componentId = $_instance->getRenderedChildComponentId('l1100580637-0');
    $componentTag = $_instance->getRenderedChildComponentTagName('l1100580637-0');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l1100580637-0');
} else {
    $response = \Livewire\Livewire::mount('select-round');
    $html = $response->html();
    $_instance->logRenderedChild('l1100580637-0', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    <div class="container-fluid mt-2">
        <?php echo $__env->make('common.crud_header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('common.crud_message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="d-flex flex-row align-items-start col-md-12 gap-2 mb-2">
            <div class="d-flex flex-row align-items-start col-md-8 gap-2 mb-2">
                
                <?php if($allow_create): ?>
                    <?php echo $__env->make('common.crud_create_button', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php endif; ?>
                
                <?php if(isset($view_search)): ?>
                    <?php echo $__env->make($view_search, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php endif; ?>
            </div>
        </div>


        

        <div class="table-responsive bg-white">
            <?php if(isset($round_games) && $round_games->count()): ?>
                <table class="table table-hover mb-0">
                    <?php if(isset($view_table)): ?>
                        <?php echo $__env->make($view_table, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php endif; ?>
                    <tbody>
                        <?php $__currentLoopData = $round_games; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $game): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php echo $__env->make($view_list, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            <?php else: ?>
                <?php echo $__env->make('common.no_records_found', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endif; ?>
        </div>


        
        <?php if($isOpen && isset($view_form)): ?>
            <?php echo $__env->make('common.crud_modal_form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endif; ?>
    </div>
</div>

<?php /**PATH C:\laragon\www\nacionnfl\resources\views/livewire/games/index.blade.php ENDPATH**/ ?>