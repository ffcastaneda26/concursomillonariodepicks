<tr class="text-base">
    <td><?php echo e($position->position); ?></td>
    <td><?php echo e($position->user->name); ?></td>
    <td align="center"><?php echo e($position->hits); ?></td>

    <td align="center"><img src="<?php echo e($position->hit_last_game  ? asset('images/afirmativo.png') : asset('images/negativo.png')); ?>"
        alt="X" width="17" height="17">
    </td>

    <td align="center"><?php echo e($position->dif_total_points); ?></td>
    <td align="center"><?php echo e($position->best_shot); ?></td>
    <td align="center"><?php echo e($position->dif_winner_points); ?></td>
    <td align="center"><?php echo e($position->dif_victory); ?></td>
</tr>

<?php /**PATH C:\laragon\www\nacionnfl\resources\views/livewire/positions/round/list.blade.php ENDPATH**/ ?>