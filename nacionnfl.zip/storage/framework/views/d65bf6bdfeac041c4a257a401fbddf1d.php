<tr>
    <td><?php echo e($loop->index + 1); ?></td>
    <td><?php echo e($position->name); ?></td>
    <td align="center"><?php echo e($position->hits ?  $position->hits : '-'); ?></td>
    <td align="center"><?php echo e($position->hit_last_games ? $position->hit_last_games : '-'); ?></td>
    <td align="center"><?php echo e($position->dif_total_points ? $position->dif_total_points : '-'); ?></td>
</tr>

<?php /**PATH C:\laragon\www\nacionnfl\resources\views/livewire/positions/general/list.blade.php ENDPATH**/ ?>