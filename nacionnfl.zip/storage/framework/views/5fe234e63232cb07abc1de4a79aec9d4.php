<div>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('select-round')->html();
} elseif ($_instance->childHasBeenRendered('l4155223527-0')) {
    $componentId = $_instance->getRenderedChildComponentId('l4155223527-0');
    $componentTag = $_instance->getRenderedChildComponentTagName('l4155223527-0');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l4155223527-0');
} else {
    $response = \Livewire\Livewire::mount('select-round');
    $html = $response->html();
    $_instance->logRenderedChild('l4155223527-0', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    <div class="container-fluid mt-2">
        <?php if(isset($records )): ?>
            <div class="row">
                <div class="col-sm-12">
                    <div class="card">
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-striped table-hover text-xs">
                                    <?php echo $__env->make('livewire.positions.round.table', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                    <tbody>
                                        <?php $__currentLoopData = $records; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $position): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php echo $__env->make('livewire.positions.round.list', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                                <div>
                                    <?php echo e($records->links()); ?>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        <?php endif; ?>
    </div>
</div>
<?php /**PATH C:\laragon\www\nacionnfl\resources\views/livewire/positions/round/index.blade.php ENDPATH**/ ?>