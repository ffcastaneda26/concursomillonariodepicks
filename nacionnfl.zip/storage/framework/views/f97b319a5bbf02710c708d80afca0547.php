<thead class="thead">
    <tr class="bg-dark text-white text-center text-sm">
        
        <th rowspan="2" valign="middle">PARTICIPANTE</th>
        <?php $__currentLoopData = $round_games; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $game): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <td><label  class="<?php echo e($game->winner == 2 ? 'font-bold text-base' : ''); ?>"> <?php echo e($game->visit_team->short); ?></label>
                -
                <label  class="<?php echo e($game->winner == 1 ? 'font-bold text-base' : ''); ?>"> <?php echo e($game->local_team->short); ?></label>
            </td>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <th rowspan="2" valign="middle">ACIERTOS</th>
    </tr>
    <tr class="bg-dark text-white text-center text-sm">
        <?php $__currentLoopData = $round_games; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $game): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <td>
            <?php if($game->visit_points || $game->local_pints): ?>
                <?php echo e($game->visit_points ? $game->visit_points : '0'); ?>

                -
                <?php echo e($game->local_points ? $game->local_points : '0'); ?>

            <?php endif; ?>
        </td>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tr>
</thead>
<?php /**PATH C:\laragon\www\nacionnfl\resources\views/livewire/results/header_game_teams.blade.php ENDPATH**/ ?>