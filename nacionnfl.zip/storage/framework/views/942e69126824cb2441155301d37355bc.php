
<td>
    <input type="radio"
            wire:model='picks.<?php echo e($loop->index); ?>'
            name="winner-<?php echo e($loop->index); ?>"
            class="<?php echo e(!$allow_pick  ? ' bg-gray-500' : ''); ?>"
            value="2"
            <?php echo e(!$allow_pick  ? 'disabled' : ''); ?>

            <?php echo e(isset($pick_user) && $pick_user->winner == 2 ? 'checked' : ''); ?>

    />
</td>


<?php echo $__env->make('livewire.picks.pick_icono_acerto', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<td>
    <input type="radio"
                wire:model='picks.<?php echo e($loop->index); ?>'
                name="winner-<?php echo e($loop->index); ?>"
                class="<?php echo e(!$allow_pick  ? ' bg-gray-500' : ''); ?>"
                value="1"
                <?php echo e(!$allow_pick  ? 'disabled' : ''); ?>

                <?php echo e(isset($pick_user) && $pick_user->winner == 1 ? 'checked' : ''); ?>

        />

</td>
<?php /**PATH C:\laragon\www\nacionnfl\resources\views/livewire/picks/pick_pick_result.blade.php ENDPATH**/ ?>