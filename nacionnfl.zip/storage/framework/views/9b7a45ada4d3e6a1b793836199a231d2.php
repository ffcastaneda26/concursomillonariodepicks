<?php
    $allow_pick     = $game->allow_pick();
    $is_last_game   = $game->is_last_game_round();
    $pick_user      = $game->pick_user();
    $print_score    = $game->print_score();
    $acerto         = $game->has_result() && $pick_user && $pick_user->winner == $game->winner;

?>
<tr>
    <td><?php echo e($game->game_day->format('j-M-y')); ?> <?php echo e($game->hour); ?></td>
        <td>
        <?php if(!$allow_pick && !$pick_user->selected): ?>
            <span class="badge rounded-pill bg-gray-500">X</span>
        <?php else: ?>
            <input type="checkbox"
                wire:model='selected.<?php echo e($game->id); ?>'
                <?php echo e(!$allow_pick                                  ? 'disabled' : ''); ?>

                class="<?php echo e(isset($pick_user) && $pick_user->selected && !$allow_pick ? 'bg-gray-500' : ''); ?>"
                <?php echo e(isset($pick_user) && $pick_user->selected     ? 'checked' : ''); ?>

            />
            <?php if(!$allow_pick): ?>
                <span class="badge rounded-pill bg-gray-500">NO EDITABLE</span>
            <?php endif; ?>
        <?php endif; ?>


    </td>


    <td class="text-xl <?php echo e($game->handicap*-1 < 0 ? 'text-danger' : ''); ?>"><?php echo e($game->handicap*-1 != 0 ? number_format($game->handicap*-1, 1, '.', ',') : ''); ?></td>

    <?php echo $__env->make('livewire.picks.pick_visit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php if( $is_last_game): ?>
        <td><input type='number' wire:model="points_visit_last_game" min=0 max=99 class="<?php echo e($error =='visit' || $error =='tie' ? 'bg-red-500' : ''); ?>"></td>
        
        <?php echo $__env->make('livewire.picks.pick_icono_acerto', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <td><input type='number' wire:model="points_local_last_game" min=0 max=99 class="<?php echo e($error =='local' || $error =='tie' ? 'bg-red-500' : ''); ?>"></td>
    <?php else: ?>
        <?php echo $__env->make('livewire.picks.pick_pick_result', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>
    <?php echo $__env->make('livewire.picks.picks_local', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <td class="text-xl <?php echo e($game->handicap < 0 ? 'text-danger' : ''); ?>" ><?php echo e($game->handicap != 0 ? number_format($game->handicap, 1, '.', ',') : ''); ?></td>


</tr>

<?php /**PATH C:\laragon\www\nacionnfl\resources\views/livewire/picks/pick_list.blade.php ENDPATH**/ ?>