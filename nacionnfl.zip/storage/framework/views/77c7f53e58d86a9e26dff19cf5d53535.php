<div class="modal fade bs-example-modal-lg show" tabindex="-1" aria-labelledby="myModal" style="display: block; padding-right: 15px;" aria-modal="true" role="dialog">
    <div class="modal-dialog modal-dialog-centered <?php echo e($modal_size); ?>">
        <div class="modal-content bg-gray-500">
            <?php echo $__env->make('common.crud_modal_header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <?php echo $__env->make($view_form, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <?php echo $__env->make('common.crud_modal_footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        </div>
    </div>
</div>
<?php /**PATH C:\laragon\www\nacionnfl\resources\views/common/crud_modal_form.blade.php ENDPATH**/ ?>