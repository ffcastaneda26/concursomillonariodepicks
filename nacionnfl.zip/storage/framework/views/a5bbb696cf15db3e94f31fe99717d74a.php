<thead class="thead">
    <tr class="bg-dark text-white text-center">
        <th>Pos</th>
        <th>Participante  </th>
        <th>Aciertos</th>
        <th>¿Paritidos Desempate?</th>
        <th>Error Acumulado</th>
    </tr>
</thead>

<?php /**PATH C:\laragon\www\nacionnfl\resources\views/livewire/positions/general/table.blade.php ENDPATH**/ ?>