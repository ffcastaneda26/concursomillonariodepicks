<div class="mt-5">
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('select-round')->html();
} elseif ($_instance->childHasBeenRendered('l3202464275-0')) {
    $componentId = $_instance->getRenderedChildComponentId('l3202464275-0');
    $componentTag = $_instance->getRenderedChildComponentTagName('l3202464275-0');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l3202464275-0');
} else {
    $response = \Livewire\Livewire::mount('select-round');
    $html = $response->html();
    $_instance->logRenderedChild('l3202464275-0', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    <div class="container-fluid mt-2">
        <?php if(isset($round_games) && !empty($round_games)): ?>
            <div class="row">
                <div class="col-sm-12">
                    <div class="card">
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table text-xs">
                                    <?php echo $__env->make('livewire.results.header_game_teams', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                                    <tbody>
                                        <?php $__currentLoopData = $users_with_picks_round; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pick_user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('picks-round-user', ['user' => $pick_user,'round' => $selected_round])->html();
} elseif ($_instance->childHasBeenRendered($pick_user->id)) {
    $componentId = $_instance->getRenderedChildComponentId($pick_user->id);
    $componentTag = $_instance->getRenderedChildComponentTagName($pick_user->id);
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild($pick_user->id);
} else {
    $response = \Livewire\Livewire::mount('picks-round-user', ['user' => $pick_user,'round' => $selected_round]);
    $html = $response->html();
    $_instance->logRenderedChild($pick_user->id, $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        <?php endif; ?>
    </div>
</div>
<?php /**PATH C:\laragon\www\nacionnfl\resources\views/livewire/results/index.blade.php ENDPATH**/ ?>