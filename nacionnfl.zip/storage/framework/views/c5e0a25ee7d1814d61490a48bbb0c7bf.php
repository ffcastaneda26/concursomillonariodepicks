<div class="container">
    <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.validation-errors','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('validation-errors'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
    <?php echo e($error_message); ?>


    <div class="row align-items-start mt-2">
        <div class="col-md-3 flex flex-col">
            <label class="input-group-text mb-2">Jornada</label>
            <label class="input-group-text mb-2">Fecha</label>
            <label class="input-group-text mb-2">Hora</label>
            <label class="input-group-text mb-2">Local</label>
            <label class="input-group-text mb-2">Pts Local</label>
            <label class="input-group-text mb-2">Visita</label>
            <label class="input-group-text mb-2">Pts Visita</label>
               <label class="input-group-text mb-2">Línea</label>
        </div>

        
        <div class="col flex flex-col">
            
            <select wire:model="main_record.round_id"
                      class="form-select rounded w-auto mb-2">
                    <option value="">Local</option>
                    <?php $__currentLoopData = $rounds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $round): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($round->id); ?>">
                                <?php echo e($round->id .' Del ' .$round->start_date->format('j-M-y') .' al ' . $round->end_date->format('j-M-y')); ?>

                            </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>

            
            <input wire:model="main_record.game_day"
                        type="date"
                        class="p-2  border rounded-md w-30"
                        required
                >

            
            <input type="time"
                    wire:model="main_record.game_time"
                    class="form-control  mb-2"
            >

            
            <select wire:model="main_record.local_team_id"
                    class="form-select rounded w-auto mb-2">
                    <option value="">Local</option>
                    <?php $__currentLoopData = $teams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $local_team): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($local_team->id); ?>">
                                <?php echo e($local_team->alias); ?>

                            </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>

            
            <input type="number"
                    wire:model="main_record.local_points"
                    class="form-control mb-2 <?php $__errorArgs = ['main_record.local_points'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
            >

            
            <select wire:model="main_record.visit_team_id"
                    class="form-select rounded w-auto mb-2">
                    <option value="">Visita</option>
                    <?php $__currentLoopData = $teams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $visit_team): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($visit_team->id); ?>">
                                <?php echo e($visit_team->alias); ?>

                            </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>

            
            <input type="number"
                    wire:model="main_record.visit_points"
                    class="form-control mb-2 <?php $__errorArgs = ['main_record.visit_points'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
            >

            
            <input type='number'
                    wire:model="main_record.handicap"
                    step='0.5'
                    value='0.00'
                    placeholder='0.0'
                    class="form-control  mb-2 <?php $__errorArgs = ['main_record.handicap'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"/>
            <?php $__errorArgs = ['main_record.handicap'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="badge rounded-pill bg-danger"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

        </div>
    </div>
</div>
<?php /**PATH C:\laragon\www\nacionnfl\resources\views/livewire/games/form.blade.php ENDPATH**/ ?>