<tr class="text-base">

    <td><?php echo e($game->game_day->format('j-M-y')); ?> <?php echo e($game->hour); ?></td>

    <td align="center">
        <label for="">
                <?php echo e($game->handicap != 0 ? number_format($game->handicap*-1, 1, '.', ',') : '-'); ?>

        </label>
    </td>
    <td>
        <?php if($game->visit_team->logo): ?>
            <img src="<?php echo e(Storage::url($game->visit_team->logo)); ?>" class="avatar-sm" alt="">

        <?php endif; ?>
    </td>

    <td><?php echo e($game->visit_team->alias); ?></td>
    <td align="center">
        <label class="<?php echo e($game->winner == 2 ? 'text-xl font-extrabold' : ''); ?>">
            <?php if($game->has_result()): ?>
                <?php echo e($game->visit_points ? $game->visit_points : '0'); ?>

            <?php endif; ?>
        </label>
    </td>

    <td align="center">
        <label class="<?php echo e($game->winner == 1 ? 'text-2xl font-extrabold' : ''); ?>">
            <?php if($game->has_result()): ?>
                <?php echo e($game->local_points ? $game->local_points : '0'); ?>

            <?php endif; ?>
        </label>

    </td>
    <td>
        <?php if($game->local_team->logo): ?>
            <img src="<?php echo e(Storage::url($game->local_team->logo)); ?>" class="avatar-sm" alt="">
        <?php endif; ?>
    </td>
    <td><?php echo e($game->local_team->alias); ?></td>
    <td align="center">
        <label for="">
                <?php echo e($game->handicap != 0 ? number_format($game->handicap, 1, '.', ',') : '-'); ?>

        </label>
    </td>
    <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasRole', 'Admin')): ?>
        <td  class="px-1 text-center">
            
            <button
                wire:click="edit(<?php echo e($game->id); ?>)"
                class="btn btn-success waves-effect waves-light"
                title="<?php echo e(__("Edit")); ?>">
                <i class="mdi mdi-eye-circle"></i>
            </button>
        </td>
    <?php endif; ?>

</tr>
<?php /**PATH C:\laragon\www\nacionnfl\resources\views/livewire/games/list.blade.php ENDPATH**/ ?>