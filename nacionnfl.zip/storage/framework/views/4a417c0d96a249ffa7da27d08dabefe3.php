    

    <td><img src="<?php echo e(Storage::url($game->visit_team->logo)); ?>" class="avatar-sm" alt="" width="100px" height="100px"></td>
    <td><?php echo e($game->visit_team->alias); ?></td>
        <td class="font-extrabold <?php echo e($acerto && $pick_user->winner == 2 ? 'text-2xl ' : 'text-xl'); ?>">
        <?php echo e($game->visit_points); ?>

    </td>
<?php /**PATH C:\laragon\www\nacionnfl\resources\views/livewire/picks/pick_visit.blade.php ENDPATH**/ ?>