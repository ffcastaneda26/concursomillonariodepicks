<a href="/">
    
    <img class="rounded-xs" src="<?php echo e(asset('images/logo.jfif')); ?>" width="120px" height="120px">
</a>
<?php /**PATH C:\laragon\www\nacionnfl\resources\views/components/authentication-card-logo.blade.php ENDPATH**/ ?>