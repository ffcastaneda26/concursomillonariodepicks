<div class="mt-5">
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('select-round')->html();
} elseif ($_instance->childHasBeenRendered('l1930543364-0')) {
    $componentId = $_instance->getRenderedChildComponentId('l1930543364-0');
    $componentTag = $_instance->getRenderedChildComponentTagName('l1930543364-0');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l1930543364-0');
} else {
    $response = \Livewire\Livewire::mount('select-round');
    $html = $response->html();
    $_instance->logRenderedChild('l1930543364-0', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    <div class="container-fluid mt-2">
        <div class="flex justify-between">
            <div >
               <?php if(isset($message)): ?>
                    <h1 class=" <?php echo e($error !='success' ? 'text-red-600 text-danger ' : 'text-success bg-green-400'); ?>text-center text-3xl"><?php echo e($message); ?></h1>
                <?php endif; ?>
            </div>
            <div class="float-right">
                <button wire:click="store" class="btn btn-primary float-right">ACTUALIZAR PRONÓSTICOS</button>
            </div>
        </div>

        <?php if(isset($round_games )): ?>
            <div class="row">
                <div class="col-sm-12">
                    <div class="card">
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-striped table-hover text-xs">
                                    <thead class="thead">
                                        <tr class="bg-dark text-white text-center">
                                            
                                            <th>Fecha</th>
                                            <th>Selecciona</th>
                                            <th>Línea</th>
                                            <th colspan="3">Visita</th>
                                            <th colspan="3">Pronóstico  </th>
                                            <th colspan="3">Local</th>
                                            <th>Línea</th>
                                        </tr>
                                    </thead>

                                    <tbody>
                                        <?php $__currentLoopData = $round_games; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $game): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <input wire:model='gamesids.<?php echo e($loop->index); ?>' type="text" class="hidden"/>
                                              <?php echo $__env->make('livewire.picks.pick_list', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                                <div class="flex justify-between">
                                        <div >
                                           <?php if(isset($message)): ?>
                                                <h1 class=" <?php echo e($error !='success' ? 'text-red-600 text-danger ' : 'text-success bg-green-400'); ?>text-center text-3xl"><?php echo e($message); ?></h1>
                                            <?php endif; ?>
                                        </div>
                                        <div class="float-right">
                                            <button wire:click="store" class="btn btn-primary float-right">ACTUALIZAR PRONÓSTICOS</button>

                                        </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        <?php endif; ?>
    </div>
</div>
<?php /**PATH C:\laragon\www\nacionnfl\resources\views/livewire/picks/index.blade.php ENDPATH**/ ?>