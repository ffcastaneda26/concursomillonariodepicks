<div class="mt-2">
    <td class="text-base"><?php echo e($user->name); ?></td>
    <?php $__currentLoopData = $user_picks_round; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user_pick_round): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <td align="center">
            <?php if($user_pick_round->game->allow_pick()): ?>
                <img src="<?php echo e(asset('images/reloj.jpg')); ?>" alt="" width="32px" height="32px">
            <?php else: ?>
                <?php if($user_pick_round->winner== 1): ?>
                    <img src="<?php echo e(Storage::url($user_pick_round->game->local_team->logo)); ?>"  class="avatar-xs" alt="" width="25px" height="25px">
                <?php else: ?>
                    <img src="<?php echo e(Storage::url($user_pick_round->game->visit_team->logo)); ?>"  class="avatar-xs" alt="" width="25px" height="25px">
                <?php endif; ?>

                <?php if( $user_pick_round->game->has_result()): ?>
                    <span>
                        <img src="<?php echo e($user_pick_round->winner       == $user_pick_round->game->winner  ?   asset('images/afirmativo.png') : asset('images/negativo.png')); ?>"
                                    alt="<?php echo e($user_pick_round->winner == $user_pick_round->game->winner  ?  __('Yes') : 'No'); ?>"
                                    height="12px"
                                    width="12px">
                    </span>
                <?php endif; ?>
                <?php if($user_pick_round->selected): ?>
                    <span class="bg-dark text-white text-center text-sm">SEL</span>
                <?php endif; ?>
            <?php endif; ?>
        </td>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <td class="text-base"><?php echo e($user->has_position_record_round($round->id) ? $user->hits_round($round->id) :''); ?></td>
</div>

<?php /**PATH C:\laragon\www\nacionnfl\resources\views/livewire/picks-round-user.blade.php ENDPATH**/ ?>