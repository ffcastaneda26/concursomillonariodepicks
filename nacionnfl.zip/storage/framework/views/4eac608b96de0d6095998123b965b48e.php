<thead class="thead">
    <tr class="bg-dark text-white text-center text-sm">
        <th>Fecha</th>
        <th>Línea </th>
        <th colspan="2">Visita</th>
        <th>Puntos Visita </th>
        <th>Puntos Local </th>
        <th colspan="2">Local</th>
        <th>Línea </th>

        <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasRole', 'Admin')): ?>
            <th>Editar</th>
        <?php endif; ?>
    </tr>
</thead>
<?php /**PATH C:\laragon\www\nacionnfl\resources\views/livewire/games/table.blade.php ENDPATH**/ ?>