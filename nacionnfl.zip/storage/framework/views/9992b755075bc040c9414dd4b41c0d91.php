
<?php $__env->startSection('main_title'); ?>
    <h4 class="page-title">
        <?php if(isset($manage_title)): ?>
            <?php echo e(__($manage_title)); ?>

        <?php endif; ?>
    </h4>
<?php $__env->stopSection(); ?>

<?php /**PATH C:\laragon\www\nacionnfl\resources\views/common/crud_header.blade.php ENDPATH**/ ?>