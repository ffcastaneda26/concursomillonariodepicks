<thead class="thead">
    <tr class="bg-dark text-white text-center">
        <th>Pos</th>
        <th>Participante  </th>
        <th>Aciertos</th>
        <th>¿Partido Desempate?</th>
        <th>Error Total</th>
        <th>Best Shot</th>
        <th>Error Ganador</th>
        <th>Diferencia Victoria</th>
    </tr>
</thead>
<?php /**PATH C:\laragon\www\nacionnfl\resources\views/livewire/positions/round/table.blade.php ENDPATH**/ ?>