<thead class="thead">
    <tr class="bg-dark text-white text-center text-sm">
        <th>Fecha</th>
        <th>Línea </th>
        <th colspan="2">Visita</th>
        <th>Puntos Visita </th>
        <th>Puntos Local </th>
        <th colspan="2">Local</th>
        <th>Línea </th>

        @role('Admin')
            <th>Editar</th>
        @endrole
    </tr>
</thead>
