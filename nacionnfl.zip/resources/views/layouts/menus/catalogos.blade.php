<li>
    <a href="javascript: void(0);" class="has-arrow waves-effect">
        <i class="mdi mdi-file-cabinet"></i>
        <span>Catálogos</span>
    </a>
    <ul class="sub-menu mm-collapse" aria-expanded="false">
        @include('layouts.menus.catalogos_generales')
    </ul>

</li>
