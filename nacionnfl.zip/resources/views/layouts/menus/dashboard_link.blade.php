<li>
    <a href="{{route('dashboard')}}" class="waves-effect">
        <i class="mdi mdi-home"></i>
        <span> {{__('Home')}} </span>
        </a>
</li>
