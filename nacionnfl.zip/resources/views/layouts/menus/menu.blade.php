
@role('admin')
    <li>@include('layouts.menus.admin')</li>
@endrole


@role('moderador')
    <li>@include('layouts.menus.admin')</li>
@endrole


@role('moderador')
    <li>@include('layouts.menus.participante')</li>
@endrole




