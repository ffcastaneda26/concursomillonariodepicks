<button type="button"
        class="btn btn-sm px-3 font-size-24 header-item waves-effect"
        id="vertical-menu-btn">
    <i class="mdi mdi-menu"></i>
</button>
