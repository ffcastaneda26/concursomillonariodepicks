<!-- LOGO -->
<div class="navbar-brand-box text-center">
    <a href="{{route('dashboard')}}" class="logo logo-light">
        <img  src="{{asset('images/logo.png')}}" class="avatar-xs">
    </a>
</div>
