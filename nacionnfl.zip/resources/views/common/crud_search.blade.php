<!-- Search input -->
<div class="search-bar">
    <input class="search-input form-control"
            wire:model="search"
            placeholder="{{__($search_label)}}"
    >
</div>