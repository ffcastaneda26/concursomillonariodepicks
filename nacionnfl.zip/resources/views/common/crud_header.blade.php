
@section('main_title')
    <h4 class="page-title">
        @if(isset($manage_title))
            {{__($manage_title)}}
        @endif
    </h4>
@endsection

