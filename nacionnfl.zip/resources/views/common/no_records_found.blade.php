<div class="container">
    <div class="bg-danger text-center mt-7 text-white">
        <h1>NO SE ENCONTRARON REGISTROS</h1>
    </div>
</div>
