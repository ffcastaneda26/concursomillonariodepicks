{{-- Clase: avatar-xx md=mediano sm=pequeño  xs=Extra pequeño lg=Largo xl=Extra largo --}}
<img class="rounded-xs" src="{{ asset('images/logo.jfif') }}" width="64px" height="64px">
